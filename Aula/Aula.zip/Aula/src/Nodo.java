class Nodo {
    Aula aula;
    Nodo izquierda, derecha;

    Nodo(Aula aula) {
        this.aula = aula;
        izquierda = derecha = null;
    }
}
 