class ABB {
    Nodo raiz;

    void insert(int capacidad, String detalles, String facultad, String[] complementos) {
        raiz = insertRec(raiz, capacidad, detalles, facultad, complementos);
    }

    Nodo insertRec(Nodo raiz, int capacidad, String detalles, String facultad, String[] complementos) {
        if (raiz == null) {
            raiz = new Nodo(new Aula(capacidad, detalles, facultad, complementos));
            return raiz;
        }
        if (capacidad < raiz.aula.capacidad) {
            raiz.izquierda = insertRec(raiz.izquierda, capacidad, detalles, facultad, complementos);
        } else {
            // Insertamos en la derecha si la capacidad es mayor o igual
            raiz.derecha = insertRec(raiz.derecha, capacidad, detalles, facultad, complementos);
        }
        return raiz;
    }

    Aula findAndReduce(int capacidad, String facultad, String[] complementosNecesarios) {
        Nodo nodoAula = findRec(raiz, capacidad, facultad, complementosNecesarios, null);
        if (nodoAula != null) {
            nodoAula.aula.capacidad -= capacidad;
            if (nodoAula.aula.capacidad == 0) {
                nodoAula.aula.disponible = false;
            }
            return nodoAula.aula;
        }
        return null;
    }


    Nodo findRec(Nodo raiz, int capacidad, String facultad,
                 String[] complementosNecesarios, Nodo mejorNodo) {
        if (raiz == null) {
            return mejorNodo;
        }

        // Verificar si el aula del nodo actual cumple con los requisitos básicos
        if (raiz.aula.capacidad >= capacidad && raiz.aula.facultad.equals(facultad)
                && raiz.aula.disponible) {
            if (raiz.aula.hasComplementos(complementosNecesarios)) {
                if (mejorNodo == null || esMejorAula(raiz.aula, mejorNodo.aula)) {
                    mejorNodo = raiz;
                }
            }
        }

        // Buscar en los hijos.
        mejorNodo = findRec(raiz.izquierda, capacidad, facultad, complementosNecesarios, mejorNodo);
        mejorNodo = findRec(raiz.derecha, capacidad, facultad, complementosNecesarios, mejorNodo);

        return mejorNodo;
    }


    // Necesitas la implementación de esMejorAula
    boolean esMejorAula(Aula aula1, Aula aula2) {
        return aula1.capacidad > aula2.capacidad;
    }
}

