import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MainGUI extends JFrame {
    private JTextField txtCapacidad;
    private JTextField txtDetalles;
    private JComboBox<String> cmbTipoAula;
    private JList<String> lstRecursos;
    private JTextField txtBuscarCapacidad;
    private JComboBox<String> cmbBuscarTipoAula;
    private JList<String> lstBuscarRecursos;
    private JTextArea txtAreaResultados;
    private ABB abb;

    public MainGUI() {
        abb = new ABB();
        txtCapacidad = new JTextField(10);
        txtDetalles = new JTextField(20);

        String[] tiposAula = {"Ingeniería", "Ciencias", "Artes", "Deportes"};
        cmbTipoAula = new JComboBox<>(tiposAula);

        String[] recursos = {"Proyector", "Computadora", "Pizarra", "Laboratorio"};
        lstRecursos = new JList<>(recursos);
        lstRecursos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        txtBuscarCapacidad = new JTextField(10);
        cmbBuscarTipoAula = new JComboBox<>(tiposAula);
        lstBuscarRecursos = new JList<>(recursos);
        lstBuscarRecursos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        txtAreaResultados = new JTextArea(5, 30);
        JButton btnInsertar = new JButton("Insertar");
        JButton btnBuscar = new JButton("Buscar y Reducir");

        setLayout(new FlowLayout());
        add(new JLabel("Capacidad:"));
        add(txtCapacidad);
        add(new JLabel("Detalles:"));
        add(txtDetalles);
        add(new JLabel("Area:"));
        add(cmbTipoAula);
        add(new JLabel("Complemento:"));
        add(new JScrollPane(lstRecursos));
        add(btnInsertar);
        add(new JLabel("Buscar Capacidad:"));
        add(txtBuscarCapacidad);
        add(new JLabel("Area:"));
        add(cmbBuscarTipoAula);
        add(new JLabel("Complemento:"));
        add(new JScrollPane(lstBuscarRecursos));
        add(btnBuscar);
        add(new JScrollPane(txtAreaResultados));

        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int capacidad = Integer.parseInt(txtCapacidad.getText());
                    String detalles = txtDetalles.getText();
                    String tipoAula = (String) cmbTipoAula.getSelectedItem();
                    List<String> recursosSeleccionados = lstRecursos.getSelectedValuesList();
                    String[] recursosArray = recursosSeleccionados.toArray(new String[0]);

                    abb.insert(capacidad, detalles, tipoAula, recursosArray);
                    txtAreaResultados.append("Aula insertada correctamente.\n");

                } catch (NumberFormatException ex) {
                    txtAreaResultados.append("Por favor, ingrese un número válido para la capacidad.\n");
                } catch (Exception ex) {
                    txtAreaResultados.append("Error al insertar aula: " + ex.getMessage() + "\n");
                }
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int capacidadBusqueda = Integer.parseInt(txtBuscarCapacidad.getText());
                    String tipoAulaBusqueda = (String) cmbBuscarTipoAula.getSelectedItem();
                    List<String> recursosBusqueda = lstBuscarRecursos.getSelectedValuesList();
                    String[] recursosBusquedaArray = recursosBusqueda.toArray(new String[0]);

                    Aula aulaAsignada = abb.findAndReduce(capacidadBusqueda, tipoAulaBusqueda, recursosBusquedaArray);

                    if (aulaAsignada != null) {
                        txtAreaResultados.append("Aula asignada: " + aulaAsignada.detalles + "\n");
                    } else {
                        txtAreaResultados.append("No se encontró un aula adecuada.\n");
                    }

                } catch (NumberFormatException ex) {
                    txtAreaResultados.append("Por favor, ingrese un número válido para la capacidad de búsqueda.\n");
                } catch (Exception ex) {
                    txtAreaResultados.append("Error al buscar aula: " + ex.getMessage() + "\n");
                }
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainGUI();
            }
        });
    }
}

